<footer>
    &copy; 2025 Recipe Sharing Platform. All Rights Reserved.
</footer>
</body>
</html>
